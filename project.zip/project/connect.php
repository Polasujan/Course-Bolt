<?php
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$username=$_POST['username'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$dob=$_POST['dob'];
$password=$_POST['password'];

echo"welcome";
?>